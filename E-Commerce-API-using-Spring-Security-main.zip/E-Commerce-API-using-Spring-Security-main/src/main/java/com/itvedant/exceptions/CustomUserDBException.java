package com.itvedant.exceptions;

public class CustomUserDBException extends RuntimeException {

	public CustomUserDBException(String message)
	{
		super(message);
	}


	
}
