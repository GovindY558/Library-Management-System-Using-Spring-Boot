package com.libraryManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.libraryManagement.entity.Book;
import com.libraryManagement.repo.LibraryRepository;

@Service
public class LibraryService {
	
	@Autowired
	private LibraryRepository lRepo;
	
	public void save(Book b) {
		lRepo.save(b);
		
	}
	
	public Book getBookById(int id) {
		return lRepo.findById(id).get();
	}
	
	public List<Book> getAllBook(){
		return lRepo.findAll();
	}
	
	public void deleteById(int id) {
		lRepo.deleteById(id);
	}

}
