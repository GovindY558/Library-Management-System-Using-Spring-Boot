package com.libraryManagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.libraryManagement.entity.Book;
import com.libraryManagement.entity.MyBookList;
import com.libraryManagement.service.LibraryService;
import com.libraryManagement.service.MyBookListService;

import java.util.*;

@Controller
public class LibraryController {

	@Autowired
	private LibraryService service;

	@Autowired
	private MyBookListService myBookService;

	@GetMapping("/")
	public String home() {
		return "home";
	}

	@GetMapping("/book_register")
	public String bookRegister(Model model) {
		Book b = new Book();
		model.addAttribute("b", b);
		return "bookRegister";
	}

	@GetMapping("/available_books")
	public String getAllBook(Model model) {

		List<Book> book = service.getAllBook();
		model.addAttribute("book", book);
		return "bookList";

	}
//	public ModelAndView getAllBook() {
//		List<Book> list =service.getAllBook();
////		ModelAndView m=new ModelAndView();
////		m.setViewName("bookList");
////		m.addObject("book",List);
//		return new ModelAndView("bookList","book",list);
//
//	}

	@PostMapping("/save")
	public String addBook(@ModelAttribute("b") Book b) {
		service.save(b);
		return "redirect:/available_books";
	}

	@GetMapping("/my_books")
	public String getMyBooks(Model model) {
		List<MyBookList> list = myBookService.getAllMyBooks();
		
		for(MyBookList l : list) {
			System.out.println(l.getAuthor());
		}
		
		model.addAttribute("book", list);
		return "myBooks";
	}

	@GetMapping("/mylist/{id}")
	public String getMyList(@PathVariable("id") int id, MyBookList book) {
		book.setId(id);
		Book b = service.getBookById(id);
		book.setId(id);
		book.setAuthor(b.getAuthor());
		book.setName(b.getName());
		book.setPrice(b.getPrice());
//		MyBookList mb=new MyBookList(b.getId(),b.getName(),b.getAuthor(),b.getPrice());
		myBookService.saveMyBooks(book);
		return "redirect:/my_books";
	}

	@RequestMapping("/editBook/{id}")
	public String editBook(@PathVariable("id") int id, Model model) {
		Book b = service.getBookById(id);
		model.addAttribute("book", b);
		return "bookEdit";
	}

	@RequestMapping("/deleteBook/{id}")
	public String deleteBook(@PathVariable("id") int id) {
		service.deleteById(id);
		return "redirect:/available_books";
	}
}
